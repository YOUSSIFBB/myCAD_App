class DropUsersTable < ActiveRecord::Migration[7.2]
  def change
  end
end
