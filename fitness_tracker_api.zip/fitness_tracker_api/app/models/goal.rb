class Goal < ApplicationRecord
end
