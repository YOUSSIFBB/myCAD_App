require "application_system_test_case"

class ExamplesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit examples_url
  #
  #   assert_selector "h1", text: "Example"
  # end
end
